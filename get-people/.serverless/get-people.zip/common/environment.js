const env = {
    service: {
        host: process.env.HOST,
        path: process.env.PATH,
    }
}

module.exports = env;